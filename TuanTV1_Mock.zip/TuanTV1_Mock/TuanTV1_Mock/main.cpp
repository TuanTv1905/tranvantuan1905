#include <QApplication>
#include <QQmlApplicationEngine>
#include "dialog.h"
#include<QQmlContext>
#include "listmodel.h"
#include"playmusic.h"
#include"language.h"
#include<mediadata.h>
int main(int argc, char *argv[])
{

    QApplication app(argc, argv);
    dialog dialog1;
    listmodel listmodel1;
    playmusic playmusic1;
    Mediadata media;

    QObject::connect(&listmodel1,&listmodel::link, &playmusic1,&playmusic::play);

    QObject::connect(&playmusic1,&playmusic::tangindex, &listmodel1,&::listmodel::changeindex);

    QObject::connect(&dialog1,&dialog::listsource,&media,&Mediadata::medialist);

    QObject::connect(&media,&Mediadata::sendSong,&listmodel1,&listmodel::addelement);

    QObject::connect(&dialog1,&dialog::deletelist,&listmodel1,&listmodel::ondeletelist);

    QObject::connect(&playmusic1,&playmusic::playfirstmusic, &listmodel1,&::listmodel::changeindex);

    QQmlApplicationEngine engine;
    Language language(&engine);

    QQmlContext *appR = engine.rootContext();
    appR -> setContextProperty("dialog",&dialog1);

    appR -> setContextProperty("listmodel",&listmodel1);

    appR -> setContextProperty("playmusic",&playmusic1);

    appR -> setContextProperty("language",&language);


    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    QObject *object = engine.rootObjects().at(0);
    QObject::connect(object,SIGNAL(myindex(int)),&listmodel1,SLOT (onmyindex(int)));
    QObject::connect(object,SIGNAL(play()),&playmusic1,SLOT (pause_play()));
    QObject::connect(object,SIGNAL(change(bool,int)),&listmodel1,SLOT (changeindex(bool,int)));
    QObject::connect(object,SIGNAL(random(bool,int)),&listmodel1,SLOT (randommusic(bool,int)));
    QObject::connect(object,SIGNAL(onSort(bool)),&listmodel1,SLOT (sortnamemusic(bool)));
    return app.exec();

}
