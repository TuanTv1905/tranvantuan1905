#include "language.h"

Language::Language(QQmlApplicationEngine *engine,QObject *parent)
    : QObject{parent}, m_engine(*engine)
{

}

void Language::onChangeLanguage(QString lang)
{
    QTranslator translator;
    if (translator.load(lang,":/")){
        QCoreApplication::installTranslator(&translator);
    }
    m_engine.retranslate();
}
