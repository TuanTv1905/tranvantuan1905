#include "playmusic.h"
#include<QMediaPlayer>
#include<QTime>
#include<QDebug>
playmusic::playmusic(QObject *parent)
    : QObject{parent}
{
    mplayer = new QMediaPlayer;
    maudio = new QAudioOutput;
    mplayer->setAudioOutput(maudio);
    connect(mplayer, &QMediaPlayer::durationChanged, this, &playmusic::onDurationChanged);
    connect(mplayer,&QMediaPlayer::mediaStatusChanged, this, &playmusic::changemusic);
    connect(mplayer, &QMediaPlayer::positionChanged, this,&playmusic::onPositionChanged );
}
// doc gia tri duration kieu qreal de tao thanh slider
qreal playmusic::getduration()
{
    return mduration;
}
void playmusic::setduration( qreal duration)
{
    if(mduration != duration){
        mduration = duration ;
        emit ondurationChanged(mduration);
    }
}

qreal playmusic::getvolum()
{
    return maudio->volume();
}

void playmusic::setvolum(qreal volum)
{
    if(mvolum != volum){
        maudio -> setVolume(volum);
        emit volumChanged( mvolum);
    }
}
// doc gia tri position kieu qreal de tao thanh slider
qreal playmusic::getposition()
{
    return mplayer->position();
}

void playmusic::setposition(qreal position)
{
    if(mposition != position){
        mplayer->setPosition(position);
        emit onpositionChanged(position);
    }
}
// doc gia tri Duration dang QString de hien thi len QML
QString playmusic::getdurationText()
{
    return mdurationText ;
}
// doc gia tri Position dang QString de hien thi len QML
void playmusic::setdurationText(QString durationText)
{
    if(mdurationText != durationText ){
        mdurationText = durationText;
        emit durationTextChanged( mdurationText );
    }
}

QString playmusic::getpositionText()
{
    return mpositionText;
}

void playmusic::setpositionText(QString positionText)
{
    if(mpositionText != positionText){
        mpositionText = positionText ;
        emit positionTextChanged( mpositionText );
    }
}
// play nhac
void playmusic::play(QString link)
{
    mplayer->setSource(link);  
    maudio->setVolume(50);
    mplayer->play();
    emit ImageChanged();
}
// thuc hien pause hoac play nhac
void playmusic::pause_play()
{
    if(mplayer->playbackState()== 1){
        mplayer->pause();
    }
    else if(mplayer->playbackState()== 2) {
        mplayer->play();
    }
    else{
        emit playfirstmusic(true,0);
    }
    emit ImageChanged();
}
// kiem tra bai hat da ket thuc va ban tin hieu thong bao tang index chuyen sang bai tiep theo
void playmusic::changemusic()
{
    if(mplayer->mediaStatus()==QMediaPlayer::EndOfMedia){
        emit tangindex(false,1);

    }
}
// nhan gia tri Duration thay doi
void playmusic::onDurationChanged()
{
    qint64 duration = mplayer->duration();
    long long int s = (duration/1000) % 60;
    long long int m = (duration/60000) % 60;
    long long int h = (duration/3600000) % 24;
    QString time = QTime( h,m,s).toString(" hh:mm:ss");
    setdurationText(time);
    setduration(mplayer->duration());
}
// nhan gia tri Position thay doi
void playmusic::onPositionChanged()
{
    qint64 position = mplayer->position();
    long long int s = (position/1000) % 60;
    long long int m = (position/60000) % 60;
    long long int h = (position/3600000) % 24;
    QString time = QTime( h,m,s).toString(" hh:mm:ss");
    setposition(mplayer->position());
    setpositionText(time);
}


// thay doi trang thai nut pause -> play và nguoc lai
bool playmusic::getchangedImage()
{
    if(mplayer->playbackState() == 1){
        return true;
    }
    else return false;
}

void playmusic::setchangedImage(bool changedImage)
{
    emit ImageChanged();
}


