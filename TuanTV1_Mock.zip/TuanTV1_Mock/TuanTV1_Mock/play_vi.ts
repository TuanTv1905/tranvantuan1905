<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="vi_VN">
<context>
    <name>ButtonDisplay</name>
    <message>
        <source>Vietnamese</source>
        <translation type="vanished">Việt Nam</translation>
    </message>
    <message>
        <source>English</source>
        <translation type="vanished">Tiếng Anh</translation>
    </message>
    <message>
        <source>Library</source>
        <translation type="vanished">Thư Viện</translation>
    </message>
    <message>
        <source>Open file</source>
        <translation type="vanished">Mở tệp</translation>
    </message>
    <message>
        <source>Open Folder</source>
        <translation type="vanished">Mở Thư mục</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="vanished">Ngôn Ngữ</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="vanished">Khác</translation>
    </message>
</context>
<context>
    <name>MenuBar</name>
    <message>
        <location filename="component/MenuBar.qml" line="31"/>
        <source>Vietnamese</source>
        <translation>Việt Nam</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="51"/>
        <source>English</source>
        <translation>Tiếng Anh</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="117"/>
        <source>Open file</source>
        <translation>Mở tệp</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="137"/>
        <source>Open Folder</source>
        <translation>Mở Thư mục</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="156"/>
        <source>Language</source>
        <translation>Ngôn Ngữ</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="185"/>
        <source>About</source>
        <translation>Khác</translation>
    </message>
</context>
<context>
    <name>Screen1</name>
    <message>
        <location filename="Screen/Screen1.qml" line="146"/>
        <source>Menu</source>
        <translation>Chọn</translation>
    </message>
    <message>
        <location filename="Screen/Screen1.qml" line="172"/>
        <source>Library</source>
        <translation>Thư Viện</translation>
    </message>
</context>
<context>
    <name>Screen2</name>
    <message>
        <location filename="Screen/Screen2.qml" line="23"/>
        <source>Menu</source>
        <translation>Chọn</translation>
    </message>
    <message>
        <location filename="Screen/Screen2.qml" line="50"/>
        <source>Back</source>
        <translation>Thoát</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="11"/>
        <source>Hello World</source>
        <translation>xin chao</translation>
    </message>
</context>
</TS>
