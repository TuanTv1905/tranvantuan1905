<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ButtonDisplay</name>
    <message>
        <source>Vietnamese</source>
        <translation type="vanished">Vietnamese</translation>
    </message>
    <message>
        <source>English</source>
        <translation type="vanished">English</translation>
    </message>
    <message>
        <source>Library</source>
        <translation type="vanished">Library</translation>
    </message>
    <message>
        <source>Open file</source>
        <translation type="vanished">Open Flile</translation>
    </message>
    <message>
        <source>Open Folder</source>
        <translation type="vanished">Open Foder</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="vanished">Language</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="vanished">About</translation>
    </message>
</context>
<context>
    <name>MenuBar</name>
    <message>
        <location filename="component/MenuBar.qml" line="31"/>
        <source>Vietnamese</source>
        <translation>Vietnamese</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="51"/>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="117"/>
        <source>Open file</source>
        <translation>Open Flile</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="137"/>
        <source>Open Folder</source>
        <translation>Open Foder</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="156"/>
        <source>Language</source>
        <translation>Language</translation>
    </message>
    <message>
        <location filename="component/MenuBar.qml" line="185"/>
        <source>About</source>
        <translation>About</translation>
    </message>
</context>
<context>
    <name>Screen1</name>
    <message>
        <location filename="Screen/Screen1.qml" line="146"/>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <location filename="Screen/Screen1.qml" line="172"/>
        <source>Library</source>
        <translation>Library</translation>
    </message>
</context>
<context>
    <name>Screen2</name>
    <message>
        <location filename="Screen/Screen2.qml" line="23"/>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <location filename="Screen/Screen2.qml" line="50"/>
        <source>Back</source>
        <translation>Back</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="11"/>
        <source>Hello World</source>
        <translation>hello hello</translation>
    </message>
</context>
</TS>
