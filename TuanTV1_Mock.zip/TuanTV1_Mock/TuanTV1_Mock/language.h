#ifndef LANGUAGE_H
#define LANGUAGE_H

#include <QObject>
#include<QString>
#include<QTranslator>
#include<QCoreApplication>
#include<QQmlApplicationEngine>

class Language : public QObject
{
    Q_OBJECT
public:
    explicit Language(QQmlApplicationEngine *engine, QObject *parent = nullptr);
    Q_INVOKABLE void onChangeLanguage(QString lang);
signals:
private:
    QQmlApplicationEngine &m_engine;

};

#endif // LANGUAGE_H
