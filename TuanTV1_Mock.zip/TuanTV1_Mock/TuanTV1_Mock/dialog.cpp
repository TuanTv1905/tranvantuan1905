#include "dialog.h"
#include <QFileDialog>
#include<QDebug>
#include<QDir>
#include<QStringList>
dialog::dialog(QWidget *parentW, QObject *parent)
    : QObject{parent}, mbrowser {parentW}
{
    connect(&mbrowser,&QFileDialog::accepted,this, &dialog::checkaccepted);
    mbrowser.setNameFilter("*.mp3 *.mp4");
    mbrowser.setOption(QFileDialog::ReadOnly, true);
    mbrowser.setAcceptMode(QFileDialog::AcceptOpen);
}
// open folder
void dialog::openfolder()
{
    mbrowser.setFileMode(QFileDialog::Directory);
    mbrowser.setDirectoryUrl(QUrl::fromLocalFile("C:/"));
    mbrowser.exec();

    QString sourcefolder = mbrowser.directoryUrl().toString();
    QDir directory(mbrowser.directoryUrl().toLocalFile());

    QStringList mymusic = directory.entryList(QStringList("*mp3").toList());
    QStringList name;
    mylist.clear();
    for(const QString& name : mymusic){

        mylist.append(sourcefolder +"/" +name);
    }
    emit listsource(mylist ); // goi list source nhac cho listmodel
}
// open file
void dialog::openfile()
{

    mbrowser.setFileMode(QFileDialog::ExistingFiles);
    mbrowser.setDirectoryUrl(QUrl::fromLocalFile("C:/"));
    mbrowser.exec();

}
// kiem tra file da duoc accepted hay khong
void dialog::checkaccepted()
{
    mylist.clear();
    QStringList sourcefile = mbrowser.selectedFiles().toList();
    mylist.append(sourcefile);
    emit listsource(mylist);
    emit deletelist();

}

