#ifndef MEDIADATA_H
#define MEDIADATA_H
#include<QMediaPlayer>
#include<QMediaMetaData>
#include<QAudioOutput>
#include <QObject>

class Mediadata : public QObject
{
    Q_OBJECT
public:
    explicit Mediadata(QObject *parent = nullptr);
    void loadSong();

public slots:
    // nhan listsource
    void medialist(QStringList listsource);

    void onMediaStatusChanged(QMediaPlayer::MediaStatus);

signals:
    void sendSong(QStringList content);

private:
    QStringList mlistsource;
    QMediaPlayer *mplayer;
    QAudioOutput *mAudio;
};

#endif // MEDIADATA_H
