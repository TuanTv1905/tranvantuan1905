#ifndef LISTMODEL_H
#define LISTMODEL_H
#include"dialog.h"
#include <QObject>
#include <QAbstractListModel>
#include<QUrl>
struct listmodelItem {
public:
    listmodelItem( QString namemusic,QString album, QString artist,QString sourcemusic)
        : nnamemusic(namemusic), nalbum(album), nartist(artist), nsourcemusic(sourcemusic)
    {
    };
    QString getnamemusic()const{
        return nnamemusic;
    }
    void setnamemusic(const QString &namemusic){
        if(nnamemusic != namemusic){
            nnamemusic = namemusic;
        }
    }
    QString getalbum()const{
        return nalbum;
    }
    void setalbum(const QString &album){
        if(nalbum != album){
            nalbum = album;
        }
    }
    QString getartist()const{
        return nartist;
    }
    void setartist(const QString &artist){
        if(nartist != artist){
            nartist = artist;
        }
    }
    QString getsourcemusic()const{
        return nsourcemusic;
    }
    void setsourcemusic(const QString &sourcemusic){
        if(nsourcemusic != sourcemusic){
            nsourcemusic = sourcemusic;
        }
    }
    bool operator>(const listmodelItem& item)
    {
        return QString::compare(nnamemusic, item.nnamemusic) > 0;
    }

    bool operator<(const listmodelItem& item)
    {
        return QString::compare(nnamemusic, item.nnamemusic) < 0;
    }
private:
    QString nnamemusic;
    QString nalbum;
    QString nartist;
    QString nsourcemusic;

};

class listmodel : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(QString currentnamemusic READ getcurrentnamemusic NOTIFY musicnameChanged)

public:
    explicit listmodel(QObject *parent = nullptr);

    enum musiclistRole{
        namemusicRole = Qt::UserRole +1 ,
        albumRole,
        artistRole,
        sourcemusicRole
    };
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data (const QModelIndex &index, int role = Qt::DisplayRole) const override;

    void addelement( const QStringList list);

    QString getcurrentnamemusic();

protected:
    QHash<int,QByteArray>roleNames() const override;

public slots:
    // nhan index bai hat tu QML
    void onmyindex(int index);
    // thay doi index khi nhan nut privious hoac next hoac khi het nhac
    void changeindex(bool check,int index);
    // random index
    void randommusic(bool check, int mode);
    // xoa danh sach bai hat cu sau khi mo danh sach moi
    void ondeletelist();
    // sap xep bai hat theo alphabet
    void sortnamemusic(bool button);

    //void playfirstmusic();
signals:
    // source bai hat
    void link(QString source);
    // thay doi bai hat
    void musicnameChanged();


private:
    QList<listmodelItem> nlist;
    int mindex;
    QString Source;
    bool checkbuttonrandom;


};

#endif // LISTMODEL_H
