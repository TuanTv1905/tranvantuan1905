#include "mediadata.h"
#include<QDebug>

Mediadata::Mediadata(QObject *parent)
    : QObject{parent}
{
    mplayer = new QMediaPlayer;
    mAudio = new QAudioOutput;
    mplayer->setAudioOutput(mAudio);
    connect(mplayer, &QMediaPlayer::mediaStatusChanged,
            this, &Mediadata::onMediaStatusChanged);
}
// set tung source nhac bat dau tu source dau tien
void Mediadata::loadSong()
{
    if (mlistsource.count() == 0) return;
    mplayer->setSource(mlistsource.front());

    mlistsource.pop_front();
}
// nhan source nhac
void Mediadata::medialist(QStringList listsource)
{
    mlistsource.append(listsource);
    loadSong();

}
// doc, lay thong tin bai hat: title, albumtitle, artist
void Mediadata::onMediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::LoadedMedia)
    {
        QStringList content;
        QMediaMetaData song = mplayer->metaData();
        content << song.stringValue(QMediaMetaData::Title)
                << song.stringValue(QMediaMetaData::AlbumTitle)
                << song.stringValue(QMediaMetaData::ContributingArtist)
                << mplayer->source().toString();
        loadSong();
        emit sendSong(content);   // goi thong tin len listmodel

    }
    }

