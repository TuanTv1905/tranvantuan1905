#ifndef PLAYMUSIC_H
#define PLAYMUSIC_H

#include <QObject>
#include<QMediaPlayer>
#include<QAudioOutput>

class playmusic : public QObject
{
    Q_OBJECT
    Q_PROPERTY(qreal duration READ getduration WRITE setduration NOTIFY ondurationChanged)
    Q_PROPERTY(qreal volum READ getvolum WRITE setvolum  NOTIFY  volumChanged)
    Q_PROPERTY( qreal position READ getposition WRITE setposition NOTIFY onpositionChanged)
    Q_PROPERTY(QString durationText READ getdurationText WRITE setdurationText NOTIFY durationTextChanged)
    Q_PROPERTY(QString positionText READ getpositionText WRITE setpositionText NOTIFY positionTextChanged)
    Q_PROPERTY( bool changedImage READ getchangedImage WRITE setchangedImage NOTIFY ImageChanged)
public:
    explicit playmusic(QObject *parent = nullptr);

    qreal getduration();
    void setduration( qreal duration);

    qreal getvolum();
    void setvolum(qreal volum);

    qreal getposition();
    void setposition(qreal position);

    QString getdurationText();
    void setdurationText(QString durationText);

    QString getpositionText();
    void setpositionText(QString positionText);

    bool getchangedImage();
    void setchangedImage(bool changedImage);

// thuc hien phat nhac
    Q_INVOKABLE void play(QString link );
public slots :
    // Dung or phat nhat bang nut pause
    void pause_play();
    // tu dong chuyen bai khi bai hat ket thuc
    void changemusic();
    // nhan gia tri Duration thay doi
    void onDurationChanged();
    // nhan gia tri Position thay doi
    void onPositionChanged();

signals:
    void ondurationChanged(qreal duration);
    // tin hieu thong bao chuyen bai hat ke tiep
    void tangindex(bool check,int temp);

    void volumChanged(qreal volum);

    void onpositionChanged(qreal position);

    void durationTextChanged(QString durationText );

    void positionTextChanged(QString onpositionText);

    void ImageChanged();
    // thong bao play bai hat dau tien
    void playfirstmusic(bool,int);


private:
    QMediaPlayer *mplayer;
    QAudioOutput *maudio;
    qreal mduration;
    qreal mvolum;
    qreal mposition;
    QString mdurationText;
    QString mpositionText;

};

#endif // PLAYMUSIC_H
