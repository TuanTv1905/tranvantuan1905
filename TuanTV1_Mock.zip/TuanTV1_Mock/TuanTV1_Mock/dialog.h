#ifndef DIALOG_H
#define DIALOG_H
#include<QString>
#include <QObject>
#include<QFileDialog>
class dialog : public QObject
{
    Q_OBJECT
public:
   // QStringList mylist;
    explicit dialog(QWidget *parentW = nullptr,QObject *parent = nullptr);
    Q_INVOKABLE void openfolder();
    Q_INVOKABLE void openfile();

signals:
    void listsource(QStringList path );
    //void listname1(QStringList path );
    void deletelist();
private:
    QFileDialog mbrowser;
    QStringList mylist;

public slots:
    void checkaccepted();
};

#endif // DIALOG_H
