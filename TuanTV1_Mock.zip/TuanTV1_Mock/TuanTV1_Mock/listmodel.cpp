#include "listmodel.h"

listmodel::listmodel(QObject *parent):QAbstractListModel (parent){

}

int listmodel::rowCount(const QModelIndex &parent) const{
    return  nlist.length();
}

QVariant listmodel::data(const QModelIndex &index, int role) const {
    const listmodelItem &item = nlist[index.row()];
    switch (role) {
    case namemusicRole:
        return item.getnamemusic() ;
        break;
    case albumRole:
        return item.getalbum() ;
        break;
    case artistRole:
        return item.getartist() ;
        break;
    case sourcemusicRole:
        return item.getsourcemusic() ;
        break;
    default:
        return QVariant();
    }
}
// chen du lieu bai hat vao list
void listmodel::addelement(const QStringList list){

    beginInsertRows(QModelIndex(),rowCount(),rowCount());
    nlist.append(listmodelItem(list.at(0),list.at(1) ,list.at(2),list.at(3)));
    endInsertRows();

}
// Ten bai hat hien tai dang phat
QString listmodel::getcurrentnamemusic()
{
    if(rowCount()>0){
        QString name = nlist.at(mindex).getnamemusic();
        return name;
    }
    else return "";
}
QHash<int, QByteArray> listmodel::roleNames() const {
    QHash <int,QByteArray> roles;
    roles[namemusicRole] = "namemusic";
    roles[albumRole] = "album";
    roles[artistRole] = "artist";
    roles[sourcemusicRole] = "sourcemusic";
    return roles;
}
// nhan ve index bai hat can phat
void listmodel::onmyindex(int index){

    if(mindex != index){
        mindex = index;      
    }
    Source =   nlist.at(mindex).getsourcemusic();
    emit link(Source);
    emit musicnameChanged();
}
// thuc hien next, privious, tu chuyen khi ket thuc bai hat
void listmodel::changeindex(bool check,int temp){

    if(nlist.length()==0){
        return;
    }
    if(temp == 0){
        mindex = 0;
        Source =   nlist.at(mindex).getsourcemusic();
    }
    mindex = mindex + temp;
    if(mindex >= 0 && mindex <= rowCount()-1){
        Source =   nlist.at(mindex).getsourcemusic();
    }
    else if(mindex < 0){
        mindex = rowCount()-1;
        Source = nlist.at(mindex).getsourcemusic();
    }
    else {
        mindex = 0;
        Source =   nlist.at(mindex).getsourcemusic();
    }
    if(checkbuttonrandom == true && temp==1){
        mindex = rand() % (rowCount());
        Source =   nlist.at(mindex).getsourcemusic();
    }

    emit link(Source);
    emit musicnameChanged();
}

// random index bai hat
void listmodel::randommusic(bool check, int temp)
{
    checkbuttonrandom = check;
}
// xoa danh sach bai hat cu sau khi mo danh sach moi
void listmodel::ondeletelist()
{
    nlist.clear();
    emit link("");
    emit layoutChanged();
}
// sap xep ten bai hat theo alphabet
void listmodel::sortnamemusic(bool button)
{
    if (button == true)
        {
            std::sort(nlist.begin(), nlist.end());
        }
        else
        {
            std::reverse(nlist.begin(), nlist.end());
        }
        emit layoutChanged();
}



